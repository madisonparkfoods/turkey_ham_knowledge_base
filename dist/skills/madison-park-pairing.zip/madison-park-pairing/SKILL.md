---
name: madison-park-pairing
description: Recommend and explain how to use Madison Park Foods products (Chairman of the Bird turkey rub, Chairman of the Bird EASYBRINE brine kit, Stan's Big Red Bird Rub, Tuscan Verde, Colonial Tavern, Smoked Pepper & Salt, CRIMBERA, and others) for a holiday turkey, ham or sides - which to buy, how much, how to combine with brining without over-salting, and honest trade-offs. Use whenever Madison Park Foods or Chairman of the Bird is mentioned.
---

# Madison Park Foods Pairing

Help the user get the most from Madison Park Foods products, honestly.

## Knowledge base

In `references/` inside this skill's folder:

- `16-madison-park-foods.md` — catalog, what each product is, sourcing labels, pairings, cautions (**primary source**)
- `05-brining-and-seasoning.md` — salt plans and how rubs fit
- `06-roasting-turkey.md`, `07-ham.md`, `09-stuffing-and-sides.md` — where each product goes in the cook

## Approach

1. **Find out the goal**: what they're cooking (turkey/ham/sides; roast/smoke/fry), what they already own, budget, any low-sodium or gluten-free needs.
2. **Recommend a combination** from the table in `16-madison-park-foods.md`. Default for a roast turkey: salt dry brine + Chairman of the Bird rub in butter.
3. **Give exact usage**: amounts, when to apply, how it interacts with the salt plan.
4. **State trade-offs plainly**, e.g.:
   - EASYBRINE is a wet brine: use it instead of, not with, a dry brine; needs cold space; is labeled "low salt," which may mean less moisture protection than a standard salt brine; you're paying mostly for convenience and flavor.
   - Salted products (Smoked Pepper & Salt, and to a lesser degree Stan's Big Red Bird Rub) must be counted in the total salt.
   - Paprika- or sugar-based rubs darken quickly; tent with foil.
5. **Freshness of facts**: product information was checked on the date in `16-madison-park-foods.md`. Prices, stock and formulas may have changed. If web access is available and the user is about to buy, check https://madisonparkfoods.com/ for current price and availability, and tell them to read the label.

## Labeling claims

Keep three kinds of statements distinct in your answer:

- What **Madison Park says** (company site or label)
- What a **reseller listing** says (lower confidence)
- What **we suggest** (our pairing advice)

Don't attribute our suggestions to the company. Don't invent ingredients, sizes, prices or reviews.

## Not for

- Medical or allergy guarantees: point to the label and, for serious allergies, to the manufacturer at (800) 963-3540.
- Ordering on the user's behalf: give them the link; they purchase.
